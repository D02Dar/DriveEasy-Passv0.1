<template>
  <div class="register-page">
    <div class="register-container">
      <div class="register-card">
        <div class="register-header">
          <h2>注册驾考助手</h2>
          <p>创建您的账户，开始驾考学习之旅</p>
        </div>

        <el-form
          ref="registerForm"
          :model="form"
          :rules="rules"
          class="register-form"
          @submit.prevent="handleSubmit"
        >
          <el-form-item prop="username">
            <el-input
              v-model="form.username"
              :placeholder="t('common.pleaseEnter')"
              size="large"
              :prefix-icon="User"
              clearable
            />
          </el-form-item>

          <el-form-item prop="email">
            <el-input
              v-model="form.email"
              type="email"
              :placeholder="t('common.pleaseEnter')"
              size="large"
              :prefix-icon="Message"
              clearable
            />
          </el-form-item>

          <el-form-item prop="password">
            <el-input
              v-model="form.password"
              type="password"
              :placeholder="t('common.pleaseEnter')"
              size="large"
              :prefix-icon="Lock"
              show-password
              clearable
            />
          </el-form-item>

          <el-form-item prop="confirmPassword">
            <el-input
              v-model="form.confirmPassword"
              type="password"
              placeholder="请确认密码"
              size="large"
              :prefix-icon="Lock"
              show-password
              clearable
              @keyup.enter="handleSubmit"
            />
          </el-form-item>

          <el-form-item>
            <div class="form-options">
              <el-checkbox v-model="form.agreeTerms">
                我已阅读并同意
                <el-link type="primary" @click="showTerms">
                  《用户协议》
                </el-link>
                和
                <el-link type="primary" @click="showPrivacy">
                  《隐私政策》
                </el-link>
              </el-checkbox>
            </div>
          </el-form-item>

          <el-form-item>
            <el-button
              type="primary"
              size="large"
              class="register-button"
              :loading="loading"
              @click="handleSubmit"
            >
              {{ loading ? '注册中...' : '注册' }}
            </el-button>
          </el-form-item>
        </el-form>

        <div class="register-footer">
          <p>
            已有账户？
            <router-link to="/login" class="login-link">
              立即登录
            </router-link>
          </p>
        </div>
      </div>

      <div class="register-illustration">
        <img src="/images/register-illustration.svg" alt="注册插图" />
        <h3>加入驾考助手</h3>
        <p>与数万学员一起，轻松通过驾驶考试</p>
        
        <div class="features-list">
          <div class="feature-item">
            <el-icon class="feature-icon"><Check /></el-icon>
            <span>完整题库练习</span>
          </div>
          <div class="feature-item">
            <el-icon class="feature-icon"><Check /></el-icon>
            <span>智能错题分析</span>
          </div>
          <div class="feature-item">
            <el-icon class="feature-icon"><Check /></el-icon>
            <span>实时进度跟踪</span>
          </div>
          <div class="feature-item">
            <el-icon class="feature-icon"><Check /></el-icon>
            <span>事故记录助手</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 用户协议对话框 -->
    <el-dialog
      v-model="termsVisible"
      title="用户协议"
      width="600px"
      :before-close="handleCloseTerms"
    >
      <div class="terms-content">
        <h4>1. 服务条款</h4>
        <p>欢迎使用驾考助手服务。通过注册和使用本服务，您同意遵守以下条款。</p>
        
        <h4>2. 用户责任</h4>
        <p>您有责任保护您的账户信息，包括用户名和密码的安全。</p>
        
        <h4>3. 服务内容</h4>
        <p>我们提供驾驶考试练习、事故记录等相关服务。</p>
        
        <h4>4. 隐私保护</h4>
        <p>我们承诺保护您的个人信息安全，详见隐私政策。</p>
      </div>
      <template #footer>
        <el-button @click="termsVisible = false">关闭<<</el-button>
      </template>
    </el-dialog>

    <!-- 隐私政策对话框 -->
    <el-dialog
      v-model="privacyVisible"
      title="隐私政策"
      width="600px"
      :before-close="handleClosePrivacy"
    >
      <div class="privacy-content">
        <h4>1. 信息收集</h4>
        <p>我们仅收集为您提供服务所必需的信息。</p>
        
        <h4>2. 信息使用</h4>
        <p>您的信息仅用于改善服务质量和用户体验。</p>
        
        <h4>3. 信息保护</h4>
        <p>我们采用行业标准的安全措施保护您的信息。</p>
        
        <h4>4. 信息共享</h4>
        <p>未经您同意，我们不会与第三方分享您的个人信息。</p>
      </div>
      <template #footer>
        <el-button @click="privacyVisible = false">关闭<<</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { reactive, ref } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { ElMessage } from 'element-plus'
import { User, Lock, Message, Check } from '@element-plus/icons-vue'

export default {
  name: 'Register',
  components: {
    User,
    Lock,
    Message,
    Check
  },
  setup() {
    const store = useStore()
    const router = useRouter()
    const { t } = useI18n()
    const registerForm = ref(null)
    const loading = ref(false)
    const termsVisible = ref(false)
    const privacyVisible = ref(false)

    const form = reactive({
      username: '',
      email: '',
      password: '',
      confirmPassword: '',
      agreeTerms: false
    })

    // 自定义验证规则
    const validateConfirmPassword = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请确认密码'))
      } else if (value !== form.password) {
        callback(new Error('两次输入的密码不一致'))
      } else {
        callback()
      }
    }

    const rules = {
      username: [
        { required: true, message: t('validation.pleaseEnter'), trigger: 'blur' },
        { min: 3, max: 50, message: '用户名长度在 3 到 50 个字符', trigger: 'blur' },
        { pattern: /^[a-zA-Z0-9_]+$/, message: '用户名只能包含字母、数字和下划线', trigger: 'blur' }
      ],
      email: [
        { required: true, message: t('validation.pleaseEnter'), trigger: 'blur' },
        { type: 'email', message: t('validation.pleaseEnter'), trigger: 'blur' }
      ],
      password: [
        { required: true, message: t('validation.pleaseEnter'), trigger: 'blur' },
        { min: 6, message: '密码长度至少 6 个字符', trigger: 'blur' }
      ],
      confirmPassword: [
        { required: true, validator: validateConfirmPassword, trigger: 'blur' }
      ]
    }

    const handleSubmit = async () => {
      if (!registerForm.value) return

      try {
        const valid = await registerForm.value.validate()
        if (!valid) return

        if (!form.agreeTerms) {
          ElMessage.warning(t('auth.pleaseAgreeTerms'))
          return
        }

        loading.value = true

        const result = await store.dispatch('auth/register', {
          username: form.username,
          email: form.email,
          password: form.password
        })

        if (result.success) {
          ElMessage.success(t('auth.registerSuccess'))
          // 注册成功后跳转到用户中心
          router.push('/dashboard')
        }
      } catch (error) {
        console.error('Registration failed:', error)
      } finally {
        loading.value = false
      }
    }

    const showTerms = () => {
      termsVisible.value = true
    }

    const showPrivacy = () => {
      privacyVisible.value = true
    }

    const handleCloseTerms = () => {
      termsVisible.value = false
    }

    const handleClosePrivacy = () => {
      privacyVisible.value = false
    }

    return {
      t,
      registerForm,
      form,
      rules,
      loading,
      termsVisible,
      privacyVisible,
      handleSubmit,
      showTerms,
      showPrivacy,
      handleCloseTerms,
      handleClosePrivacy,
      User,
      Lock,
      Message,
      Check
    }
  }
}
</script>

<style lang="scss" scoped>
.register-page {
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.register-container {
  display: grid;
  grid-template-columns: 1fr 1fr;
  max-width: 1100px;
  width: 100%;
  background: white;
  border-radius: 16px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

.register-card {
  padding: 60px 50px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.register-header {
  text-align: center;
  margin-bottom: 40px;

  h2 {
    font-size: 28px;
    font-weight: 700;
    color: var(--el-text-color-primary);
    margin-bottom: 10px;
  }

  p {
    color: var(--el-text-color-regular);
    font-size: 16px;
  }
}

.register-form {
  .el-form-item {
    margin-bottom: 24px;
  }

  .el-input {
    --el-input-height: 48px;
  }
}

.form-options {
  width: 100%;
  
  .el-checkbox {
    line-height: 1.6;
  }
}

.register-button {
  width: 100%;
  height: 48px;
  font-size: 16px;
  font-weight: 600;
}

.register-footer {
  text-align: center;
  margin-top: 30px;

  p {
    color: var(--el-text-color-regular);
  }

  .login-link {
    color: var(--el-color-primary);
    text-decoration: none;
    font-weight: 600;

    &:hover {
      text-decoration: underline;
    }
  }
}

.register-illustration {
  background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
  padding: 60px 40px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
  color: white;

  img {
    width: 200px;
    height: auto;
    margin-bottom: 30px;
    opacity: 0.9;
  }

  h3 {
    font-size: 24px;
    font-weight: 600;
    margin-bottom: 15px;
  }

  p {
    font-size: 16px;
    opacity: 0.9;
    line-height: 1.6;
    margin-bottom: 30px;
  }
}

.features-list {
  display: flex;
  flex-direction: column;
  gap: 15px;
  align-items: flex-start;
}

.feature-item {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 14px;

  .feature-icon {
    background: rgba(255, 255, 255, 0.2);
    border-radius: 50%;
    padding: 4px;
    font-size: 12px;
  }
}

.terms-content,
.privacy-content {
  max-height: 400px;
  overflow-y: auto;
  padding: 10px;

  h4 {
    color: var(--el-text-color-primary);
    margin: 20px 0 10px 0;
    font-size: 16px;
    font-weight: 600;

    &:first-child {
      margin-top: 0;
    }
  }

  p {
    color: var(--el-text-color-regular);
    line-height: 1.6;
    margin-bottom: 15px;
  }
}

@media (max-width: 768px) {
  .register-container {
    grid-template-columns: 1fr;
    max-width: 400px;
  }

  .register-card {
    padding: 40px 30px;
  }

  .register-illustration {
    display: none;
  }
}

@media (max-width: 480px) {
  .register-page {
    padding: 10px;
  }

  .register-card {
    padding: 30px 20px;
  }

  .register-header h2 {
    font-size: 24px;
  }
}
</style>
